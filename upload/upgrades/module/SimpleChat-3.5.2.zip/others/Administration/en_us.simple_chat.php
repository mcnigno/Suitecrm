<?php
//Admin Menu
$mod_strings['LBL_SIMPLECHAT_ACTIONS_TITLE'] = "Simple Chat Settings";
$mod_strings['LBL_SIMPLECHAT_ACTIONS_DESC'] = "Configure the Simple Chat settings and send feedback.";

$mod_strings['LBL_SIMPLECHAT_TITLE'] = "Chat Settings";
$mod_strings['LBL_SIMPLECHAT_DESCRIPTION'] = "Disable or enable Simple Chat";

$mod_strings['LBL_SIMPLECHAT_FEEDBACK_TITLE'] = "Submit bugs or suggestions";
$mod_strings['LBL_SIMPLECHAT_FEEDBACK_DESCRIPTION'] = "Submit bugs or suggestions";

$mod_strings['LBL_SIMPLECHAT_CHECK_TITLE'] = "Check for new version";
$mod_strings['LBL_SIMPLECHAT_CHECK_DESCRIPTION'] = "Check for new version of Simple Chat";

$mod_strings['LBL_SIMPLECHAT_ABOUTUS_TITLE'] = "About Us";
$mod_strings['LBL_SIMPLECHAT_ABOUTUS_DESCRIPTION'] = "About the company";

?>